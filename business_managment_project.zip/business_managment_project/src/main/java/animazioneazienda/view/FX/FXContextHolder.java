package animazioneazienda.view.FX;

import animazioneazienda.dao.AziendaDAO;
import animazioneazienda.controller.LoginController;

public class FXContextHolder {
    public static AziendaDAO aziendaDAO;
    public static LoginController loginController;
}